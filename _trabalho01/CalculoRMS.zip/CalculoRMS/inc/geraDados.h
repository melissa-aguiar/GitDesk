#ifndef _GERADADOS_H_
#define _GERADADOS_H_

void geradados(double , double , double *, double , int);

#endif 