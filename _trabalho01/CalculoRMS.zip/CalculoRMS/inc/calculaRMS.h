#ifndef _CALCULA_RMS_H_
#define _CALCULA_RMS_H_

double calcRMS(double *, int , int);

#endif 